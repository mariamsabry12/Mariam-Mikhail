/* 
 * File:   main.cpp
 * Author: mariam mikhail
 *Purpose: TIC TAC TOE
 * Created on February 9, 2024, 1:32 PM
 */
#include <iostream>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <limits>
#include <vector>

using namespace std;

const int MIN_BOARD_SIZE = 3;
const int MAX_BOARD_SIZE = 10;
const int DEFAULT_BOARD_SIZE = 3;

struct Player {
    string name;
    char symbol;
};

struct Game {
    vector<vector<char>> board;
    Player players[2];
    char winner;
};

struct GameHistory {
    vector<Game> games;
};

void initializeBoard(vector<vector<char>>& board, int size);
void displayBoard(const vector<vector<char>>& board);
bool checkWin(const vector<vector<char>>& board, char symbol);
bool checkDraw(const vector<vector<char>>& board);
void playerMove(vector<vector<char>>& board, char symbol);
void saveGame(const Game& game, const string& filename);
void loadGame(Game& game, const string& filename);
void sortPlayers(int scores[], char players[], int size);
void searchPlayer(const char players[], char player, int size);
void displayMenu();
void playGame(GameHistory& history);
void displayScores(const int scores[], const char players[], int size);
void displayTopPlayers(const int scores[], const char players[], int size);
void displayGameHistory(const GameHistory& history);
void clearScreen();
void customizeBoardSize(int& boardSize);
void playWithAI(Game& game);
void playWithPlayer(Game& game);
void displayWelcomeMessage();

int main() {
    GameHistory history;
    displayWelcomeMessage();
    playGame(history);
    return 0;
}

void initializeBoard(vector<vector<char>>& board, int size) {
    board.resize(size, vector<char>(size, '-'));
}

void displayBoard(const vector<vector<char>>& board) {
    for (int i = 0; i < board.size(); ++i) {
        for (int j = 0; j < board[i].size(); ++j) {
            cout << board[i][j] << " ";
        }
        cout << endl;
    }
}

bool checkWin(const vector<vector<char>>& board, char symbol) {
    // Check rows and columns
    for (int i = 0; i < board.size(); ++i) {
        if (count(board[i].begin(), board[i].end(), symbol) == board.size()) {
            return true; // Row win
        }
        int colCount = 0;
        for (int j = 0; j < board.size(); ++j) {
            if (board[j][i] == symbol) {
                colCount++;
            }
        }
        if (colCount == board.size()) {
            return true; // Column win
        }
    }

    // Check diagonals
    int diagCount1 = 0, diagCount2 = 0;
    for (int i = 0; i < board.size(); ++i) {
        if (board[i][i] == symbol) {
            diagCount1++;
        }
        if (board[i][board.size() - 1 - i] == symbol) {
            diagCount2++;
        }
    }
    if (diagCount1 == board.size() || diagCount2 == board.size()) {
        return true; // Diagonal win
    }

    return false;
}

bool checkDraw(const vector<vector<char>>& board) {
    for (int i = 0; i < board.size(); ++i) {
        for (int j = 0; j < board[i].size(); ++j) {
            if (board[i][j] == '-') {
                return false;
                // Empty space found, game not draw
            }
        }
    }
    return true; 
    // No empty space found, game is draw
}

void playerMove(vector<vector<char>>& board, char symbol) {
    int row, col;
    cout << "Player " << symbol << ", enter your move (row and column): ";
    while (true) 
    {
        cin >> row >> col;
        if (cin.fail() || row < 1 || row > board.size() || col < 1 || col > board.size() || board[row - 1][col - 1] != '-') {
            cout << "Invalid input or move. Please enter again: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        } else {
            break;
        }
    }
    board[row - 1][col - 1] = symbol;
}

void saveGame(const Game& game, const string& filename) {
    ofstream outFile(filename);
    if (outFile.is_open()) {
        outFile << game.players[0].name << " " << game.players[0].symbol << endl;
        outFile << game.players[1].name << " " << game.players[1].symbol << endl;
        for (const auto& row : game.board) {
            for (char cell : row) {
                outFile << cell << " ";
            }
            outFile << endl;
        }
        outFile << game.winner << endl;
        outFile.close();
        cout << "Game saved successfully." << endl;
    } else {
        cout << "Unable to save game." << endl;
    }
}

void loadGame(Game& game, const string& filename) 
{
    ifstream inFile(filename);
    if (inFile.is_open()) {
        inFile >> game.players[0].name >> game.players[0].symbol;
        inFile >> game.players[1].name >> game.players[1].symbol;
        initializeBoard(game.board, MAX_BOARD_SIZE);
        for (auto& row : game.board) {
            for (char& cell : row) {
                inFile >> cell;
            }
        }
        inFile >> game.winner;
        inFile.close();
        cout << "Game loaded successfully." << endl;
    } else {
        cout << "Unable to load game." << endl;
    }
}

void sortPlayers(int scores[], char players[], int size) 
{
    // Bubble sort
    for (int i = 0; i < size - 1; ++i) {
        for (int j = 0; j < size - i - 1; ++j) {
            if (scores[j] < scores[j + 1]) {
                swap(scores[j], scores[j + 1]);
                swap(players[j], players[j + 1]);
            }
        }
    }
}

void searchPlayer(const char players[], char player, int size) {
    for (int i = 0; i < size; ++i) {
        if (players[i] == player) {
            cout << "Player " << player << " found at position " << i + 1 << endl;
            return;
        }
    }
    cout << "Player " << player << " not found." << endl;
}

void displayMenu() {
    cout << "Welcome to Tic-Tac-Toe!" << endl;
    cout << "1. Play game" << endl;
    cout << "2. Display scores" << endl;
    cout << "3. Display top players" << endl;
    cout << "4. Display game history" << endl;
    cout << "5. Save game" << endl;
    cout << "6. Load game" << endl;
    cout << "7. Customize board size" << endl;
    cout << "8. Quit" << endl;
    cout << "Enter your choice: ";
}

void playGame(GameHistory& history) {
    Game game;
    int boardSize = DEFAULT_BOARD_SIZE;
    customizeBoardSize(boardSize);
    initializeBoard(game.board, boardSize);

    game.players[0].symbol = 'X';
    game.players[1].symbol = 'O';

    cout << "Enter Player 1 name: ";
    cin >> game.players[0].name;
    cout << "Enter Player 2 name: ";
    cin >> game.players[1].name;

    int moveCount = 0;

    while (moveCount < boardSize * boardSize) {
        clearScreen();
        cout << "Current Board:" << endl;
        displayBoard(game.board);

        playerMove(game.board, game.players[moveCount % 2].symbol);

        if (checkWin(game.board, game.players[moveCount % 2].symbol)) {
            game.winner = game.players[moveCount % 2].symbol;
            break;
        } else if (checkDraw(game.board)) {
            game.winner = 'D';
            break;
        }

        moveCount++;
    }

    clearScreen();
    cout << "Final Board:" << endl;
    displayBoard(game.board);

    if (game.winner == 'D') {
        cout << "It's a draw!" << endl;
    } else {
        cout << "Player " << game.winner << " wins!" << endl;
    }

    history.games.push_back(game);
}

void displayScores(const int scores[], const char players[], int size) {
    cout << "Scores:" << endl;
    for (int i = 0; i < size; ++i) {
        cout << "Player " << players[i] << ": " << scores[i] << endl;
    }
}

void displayTopPlayers(const int scores[], const char players[], int size) {
    int sortedScores[MAX_BOARD_SIZE];
    char sortedPlayers[MAX_BOARD_SIZE];
    copy(scores, scores + size, sortedScores);
    copy(players, players + size, sortedPlayers);
    sortPlayers(sortedScores, sortedPlayers, size);
    cout << "Top Players:" << endl;
    for (int i = 0; i < size; ++i) {
        cout << "Player " << sortedPlayers[i] << ": " << sortedScores[i] << endl;
    }
}

void displayGameHistory(const GameHistory& history) {
    cout << "Game History:" << endl;
    for (int i = 0; i < history.games.size(); ++i) {
        cout << "Game " << i + 1 << ": Winner - " << history.games[i].winner << endl;
    }
}

void clearScreen() 
{
    cout << "\033[2J\033[1;1H"; // ANSI escape sequence to clear the screen
}

void customizeBoardSize(int& boardSize) 
{
    cout << "Enter board size (between " << MIN_BOARD_SIZE << " and " << MAX_BOARD_SIZE << "): ";
    while (true) {
        cin >> boardSize;
        if (cin.fail() || boardSize < MIN_BOARD_SIZE || boardSize > MAX_BOARD_SIZE) {
            cout << "Invalid input. Please enter a number between " << MIN_BOARD_SIZE << " and " << MAX_BOARD_SIZE << ": ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        } else {
            break;
        }
    }
}

void playWithAI(Game& game) {
    // To be implemented
}

void playWithPlayer(Game& game) {
    // To be implemented
}

void displayWelcomeMessage() {
    cout << "Welcome to Tic-Tac-Toe!" << endl;
}


